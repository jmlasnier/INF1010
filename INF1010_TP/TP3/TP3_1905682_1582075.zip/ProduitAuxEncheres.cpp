/********************************************
* Titre: Travail pratique #3 - ProduitAuxEncheres.cpp
* Date: 
* Auteur:
*******************************************/

#include "ProduitAuxEncheres.h"


//Constructeur par param�tre et par d�faut de la classe ProduitAuxEncheres
ProduitAuxEncheres::ProduitAuxEncheres(Fournisseur& fournisseur, const string& nom, int reference, double prix, TypeProduit type, double prixBase, int identifiant):
	Produit(fournisseur, nom, reference, prix, type),
	prixBase_{ prixBase },
	identifiantClient_{ identifiant }
{
	prixBase_ = obtenirPrix();
}

//M�thode d'acces pour l'attribut identifiantClient_ de la classe fille
int ProduitAuxEncheres::obtenirIdentifiantClient() const
{
	return identifiantClient_;
}
//M�thode d'acces pour l'attribut prixBase_ de la classe fille
double ProduitAuxEncheres::obtenirPrixBase() const
{
	return prixBase_;
}

//M�thode de modification pour l'attribut identifiantClient_ de la classe fille
void ProduitAuxEncheres::modifierIdentifiantClient(int identifiantClient)
{
	identifiantClient_ = identifiantClient;
}

//M�thode de modification pour l'attribut prixBase_ de la classe fille
void ProduitAuxEncheres::modifierPrixBase(double prixBase)
{
	prixBase_ = prixBase;
}

//Surcharge de l'operateur >>
istream& operator>>(istream& is, ProduitAuxEncheres& produit)
{
	Produit produitUpcast = static_cast<Produit>(produit);
	return is >> produitUpcast >> produit.identifiantClient_ >> produit.prixBase_;
}

//Surcharge de l'op�rateur <<
ostream& operator<<(ostream& os, const ProduitAuxEncheres& produit)
{
	os << "ProduitAuxEncheres: "
		<< static_cast<Produit>(produit)
		<< "\t \t prixBase: " << produit.obtenirPrixBase() << endl
		<< "\t \t identifiantClient: " << produit.obtenirIdentifiantClient() << endl;
	
	return os;
}